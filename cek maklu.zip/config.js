module.exports = {
  BOT_TOKEN:
  "BOT-TOKEN",
};